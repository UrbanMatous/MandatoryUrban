using System.Text.Json;

public class GameConfiguration
{
    public int WorldWidth { get; set; }
    public int WorldHeight { get; set; }
    public string GameLevel { get; set; }

    public static GameConfiguration Load(string path = "C:\\Users\\matyu\\source\\repos\\GameFramework.Demo\\GameFramework.Demo\\config.json")
    {
        var json = File.ReadAllText("C:\\Users\\matyu\\source\\repos\\GameFramework.Demo\\GameFramework.Demo\\config.json");
        return JsonSerializer.Deserialize<GameConfiguration>(json);
    }
}