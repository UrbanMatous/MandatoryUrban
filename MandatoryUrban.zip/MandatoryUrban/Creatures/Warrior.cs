using System.Linq;

public class Warrior : Creature
{
    protected override int CalculateDamage()
    {
        return 10 + Attacks.Sum(a => a.HitPoints); // LINQ used
    }
}