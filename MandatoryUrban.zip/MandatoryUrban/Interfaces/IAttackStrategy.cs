public interface IAttackStrategy
{
    int CalculateDamage(Creature creature);
}