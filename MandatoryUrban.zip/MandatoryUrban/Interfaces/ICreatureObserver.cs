public interface ICreatureObserver
{
    void OnCreatureHit(Creature creature);
}