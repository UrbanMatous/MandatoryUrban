﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MandatoryUrban.MainClasses;

namespace MandatoryUrban.Actions
{
    public abstract class AttackDecorator : IAttackItem
    {
        protected IAttackItem _baseItem;

        public AttackDecorator(IAttackItem baseItem)
        {
            _baseItem = baseItem;
        }

        public virtual int HitPoints => _baseItem.HitPoints;
        public virtual string Description => _baseItem.Description;
    }

}
