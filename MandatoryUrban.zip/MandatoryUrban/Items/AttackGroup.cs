﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MandatoryUrban.Items
{
    public class AttackGroup : IAttackItem
    {
        private List<IAttackItem> _items = new();

        public void Add(IAttackItem item) => _items.Add(item);

        public int HitPoints => _items.Sum(i => i.HitPoints);

        public string Description => $"Group of {_items.Count} attack items";
    }
}
