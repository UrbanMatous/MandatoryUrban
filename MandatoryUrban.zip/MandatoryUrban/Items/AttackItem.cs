public class AttackItem : IAttackItem
{
    public virtual int HitPoints { get; set; }
    public string Description { get; set; }
}