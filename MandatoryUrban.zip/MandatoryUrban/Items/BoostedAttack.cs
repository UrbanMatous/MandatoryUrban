﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MandatoryUrban.MainClasses;

namespace MandatoryUrban
{
    public class BoostedAttack : AttackItem
    {
        private readonly AttackItem _baseAttack;
        public BoostedAttack(AttackItem baseAttack) { _baseAttack = baseAttack; }
        public override int HitPoints => _baseAttack.HitPoints * 2;
    }
}
