﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MandatoryUrban.Items
{
    public class DefenseItem:IDefenseItem
    {
        public virtual int Protection { get; set; }
        public string Description { get; set; }
    }
}
