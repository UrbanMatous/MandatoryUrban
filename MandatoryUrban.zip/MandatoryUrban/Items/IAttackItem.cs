public interface IAttackItem
{
    int HitPoints { get; }
    string Description { get; }
}