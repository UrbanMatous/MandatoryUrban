using MandatoryUrban.Actions;

public class LowHealthBoostDecorator : AttackDecorator
{
    private readonly Creature _owner;

    public LowHealthBoostDecorator(IAttackItem baseItem, Creature owner) : base(baseItem)
    {
        _owner = owner;
    }

    public override int HitPoints
    {
        get
        {
            if (_owner.HitPoints < 25)
                return base.HitPoints + 5;
            return base.HitPoints;
        }
    }
}