public class HitTracker : ICreatureObserver
{
    public void OnCreatureHit(Creature creature)
    {
        GameLogger.Log($"\"Observer: {creature.Name} was hit!\"");
    }
}