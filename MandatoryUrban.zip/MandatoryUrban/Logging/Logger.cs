using System;
using System.Diagnostics;

public static class GameLogger
{
    static GameLogger()
    {
        Trace.Listeners.Add(new ConsoleTraceListener());
    }

    public static void Log(string message)
    {
        Trace.WriteLine($"[{DateTime.Now}] {message}");
    }
}