using System.Linq;

public class AggressiveStrategy : IAttackStrategy
{
    public int CalculateDamage(Creature creature) =>
        creature.Attacks.Sum(a => a.HitPoints) + 5;
}