using System.Linq;

public class NormalAttackStrategy : IAttackStrategy
{
    public int CalculateDamage(Creature creature) => creature.Attacks.Sum(a => a.HitPoints);
}