﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MandatoryUrban.Items;

namespace MandatoryUrban.MainClasses
{
    public class World
    {
        public int MaxX { get; set; }
        public int MaxY { get; set; }
        public List<Creature> Creatures { get; } = new List<Creature>();
        public List<WorldObject> Objects { get; } = new List<WorldObject>();

        public World(int maxX, int maxY)
        {
            MaxX = maxX;
            MaxY = maxY;
        }
    }
}
